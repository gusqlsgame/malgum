$('.pouch_img').click(function () {
    $(this).children().toggleClass('fas').toggleClass('far');
    //alert();
});