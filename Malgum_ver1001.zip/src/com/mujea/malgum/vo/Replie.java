package com.mujea.malgum.vo;

public class Replie {

}
