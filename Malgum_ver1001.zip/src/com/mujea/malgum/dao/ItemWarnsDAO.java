package com.mujea.malgum.dao;

public interface ItemWarnsDAO {

	
	
}//ItemWarnsDAO end
