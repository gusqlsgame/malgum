package com.mujea.malgum.dao;

public interface SecondsDAO {

	
	
}//SecondsDAO end
