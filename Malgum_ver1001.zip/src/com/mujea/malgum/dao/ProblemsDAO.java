package com.mujea.malgum.dao;

public interface ProblemsDAO {

	
	
}//ProblemsDAO end
