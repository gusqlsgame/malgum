package com.mujea.malgum.dao;

import java.util.List;

import com.mujea.malgum.vo.Warn;

public interface WarnsDAO {

	public List<Warn> selectWarnList();
}
